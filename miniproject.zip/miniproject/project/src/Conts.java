public class Conts {

    public static final String SUBMIT = "Submit";

    /**/

    public static final String ANALYST = "analyst";
    public static final String ANALYST_LEADER = "analystleader";
    public static final String ANALYST_SALES = "analystsales";

    /**/

    public static final String SALES = "sales";
    public static final String INVENTORY = "inventory";
    public static final String MARKETING = "marketing";
    public static final String HUMAN_RESOURCES = "humanresources";

    /**/

    public static final String HR = "hr";
    public static final String HR_MANAGER = "hrmanager";
    public static final String HR_VIWER = "hrviewer";

    /**/

    public static final String ADMIN = "admin";

    /**/

    public static final String STANDARD = "standard";


}
