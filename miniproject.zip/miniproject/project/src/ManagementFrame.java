import java.awt.*;
/*
* Simple frame for the management employees
* */

public class ManagementFrame extends KPIFrame {
    public ManagementFrame() {
        super();
        this.setLayout(new GridLayout(0,1));
        this.setSize(400, 700);
    }
}