public interface KPIRules {
    String provideKeyMetric();
    String description();
}
