import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        new LoginFrame();
//        AnalystLeader al = new AnalystLeader("Hello");
//        AnalystLeader al1 = new AnalystLeader("Hsaddsello");
//        Analyst a = new Analyst("asdasd");
//        System.out.println(al.comparing(a));
//        Buttons ok = new
    }

}
