import java.awt.*;

public interface CompareRules {
    boolean compareTo(Object obj);
}
