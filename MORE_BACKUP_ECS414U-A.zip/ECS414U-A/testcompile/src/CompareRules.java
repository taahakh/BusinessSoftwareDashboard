import java.awt.*;

public interface CompareRules {
    boolean compare(Object obj);
}
