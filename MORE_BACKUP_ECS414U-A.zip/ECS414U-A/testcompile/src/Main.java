import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        new LoginFrame();

    }

    static void print(Object x){
        System.out.println(x);
    }
}
