public enum Method {
    ADD, REMOVE, UPDATE, TYPE
}
