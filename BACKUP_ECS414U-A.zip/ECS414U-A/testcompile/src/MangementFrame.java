import java.awt.*;

public class MangementFrame extends KPIFrame {
    public MangementFrame() {
        super();
        this.setLayout(new GridLayout(0,1));
        this.setSize(400, 700);
    }
}