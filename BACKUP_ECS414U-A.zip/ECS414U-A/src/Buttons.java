import java.util.ArrayList;

public interface Buttons {
    ArrayList<Buttons> getButtons();
}
